// Toast notification
function toast(msg){var e=document.getElementById('toast')||document.createElement('div');e.id='toast';e.className='copy-toast';e.textContent=msg;document.body.appendChild(e);e.classList.add('show');setTimeout(function(){e.classList.remove('show')},1800)}

// Copy to clipboard
function copyText(text){navigator.clipboard.writeText(text).then(function(){toast('已复制到剪贴板')}).catch(function(){toast('复制失败，请手动选择')})}

// Debounce helper
function debounce(fn,d){var t;return function(){clearTimeout(t);t=setTimeout(fn.bind(this),d)}}

// Auto-resize textarea
document.addEventListener('input',function(e){if(e.target.tagName==='TEXTAREA'){e.target.style.height='auto';e.target.style.height=e.target.scrollHeight+'px'}})
